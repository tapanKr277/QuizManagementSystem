package com.gyanpath.security.exception;

public class InvalidOtpException extends Exception{
    public InvalidOtpException(String msg){
        super(msg);
    }
}
