package com.gyanpath.security.exception;

public class QuizNotFoundException extends Exception{
    public QuizNotFoundException(String msg){
        super(msg);
    }
}
