package com.gyanpath.security.exception;

public class NotAbleToSendEmail extends Exception{
    public NotAbleToSendEmail(String msg){
        super(msg);
    }
}
