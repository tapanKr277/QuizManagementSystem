package com.gyanpath.security.exception;

public class ResourceNotFound extends Exception{
    public ResourceNotFound(String msg){
        super(msg);
    }
}
