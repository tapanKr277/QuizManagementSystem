package com.gyanpath.security.exception;

public class OtpNotFound extends Exception{
    public OtpNotFound(String msg){
        super(msg);
    }
}
