package com.gyanpath.security.exception;

public class PasswordMisMatchException extends Exception{
    public PasswordMisMatchException(String msg){
        super(msg);
    }
}
